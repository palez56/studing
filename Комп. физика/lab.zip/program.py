import math
grad = int(input("Введите градус: "))

def grad_to_rad(grad):
    return grad/360*math.pi*2

print(math.cos(grad_to_rad(grad)))