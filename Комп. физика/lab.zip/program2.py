import math
def func(r):
    k = 1 / 4 * math.pi * (8.85 * (10 ** -12))
    f = (4 * k * math.pi * (10 * 10 ** -6) * (0.01 ** 2)) / r
    return f

print("а) ", func(0.1))
r = float(input("Введите r: "))

if r > 0.01:
    print("b) ", func(r))
else:
    print("r меньше чем R")